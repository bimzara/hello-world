<script language="JavaScript1.2">


var bgslides=new Array()
bgslides[0]="bg1"

bgslides[1]="bg2"

bgslides[2]="bg3"


var speed=2000


var processed=new Array()
for (i=0;i<bgslides.length;i++){
processed[i]=new Image()
processed[i].src=bgslides[i]
}

var inc=-1

function slideback(){
if (inc<bgslides.length-1)
inc++
else
inc=0
document.body.background=processed[inc…
}

if (document.all||document.getElementById)
window.onload=new Function

